#ifndef ____MST___
#define ____MST___
#include"Map.h"
#include"Heap.h"
#include"EdgeHeap.h"
void Prim(Map Map);
void PrimUseHeap(Map Map);
void Kruskal(Map Map);
void ShowMST(Map map); //��ӡ�������ı�
#endif // !____MST___


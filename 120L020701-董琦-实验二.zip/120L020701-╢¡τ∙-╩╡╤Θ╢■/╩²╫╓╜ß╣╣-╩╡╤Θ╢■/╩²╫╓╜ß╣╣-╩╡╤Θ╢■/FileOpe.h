#ifndef  ___FILEOPE___
#define  ___FILEOPE___
#include<stdio.h>

FILE* OpenFile(char* FileName,char* mode);

#endif // ! ___FILEOPE___

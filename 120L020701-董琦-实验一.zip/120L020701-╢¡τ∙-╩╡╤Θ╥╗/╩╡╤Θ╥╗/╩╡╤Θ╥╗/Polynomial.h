#ifndef ___POLYNOMIAL___
#define ___POLYNOMIAL___
#include"List.h"

List Addition(List L1,List L2);
List Subtract(List L1, List L2);
List Multiply(List L1, List L2);
List Derivation(List L,int k);
float Calculate(List L, float x0);

#endif // !___POLYNOMIAL___


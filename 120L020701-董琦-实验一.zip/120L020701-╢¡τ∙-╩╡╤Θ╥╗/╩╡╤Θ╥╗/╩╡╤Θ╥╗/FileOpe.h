#ifndef ____FILEOPERATE__
#define ____FILEOPERATE__
#define MAXLENTH 100
#include "List.h"
void ReadFile(char C[2][40]);
void WriteFile(List L);

#endif
